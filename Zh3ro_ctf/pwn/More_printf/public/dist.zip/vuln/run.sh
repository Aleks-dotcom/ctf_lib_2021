#!/usr/bin/env bash
./ynetd -p 1337 -u user -d /vuln ./more-printf
